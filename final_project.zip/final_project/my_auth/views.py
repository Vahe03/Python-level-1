from django.contrib import messages
from django.shortcuts import render, redirect
from .forms import RegisterForm
from django.contrib.auth import login


def register(request):
    if request.method == 'POST':
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():
            username = register_form.cleaned_data['username']

            user = register_form.save()
            login(request, user)
            messages.success(request, 'Hi {username}, you have successfully registered!')
            return redirect('/')
        else:
            messages.error(request, 'Something went wrong!')


    else:
        register_form = RegisterForm()
    return render(request, 'register.html', {'form': register_form})
