from django.urls import path, include
from . import views

app_name = 'my_auth'
urlpatterns = [
    path('register/', views.register, name='register'),
    path("accounts/", include("django.contrib.auth.urls")),
]