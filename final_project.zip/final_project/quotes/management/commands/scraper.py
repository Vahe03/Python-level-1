from bs4 import BeautifulSoup
import requests

from django.core.management.base import BaseCommand
from quotes.models import Tags, Authors, Quotes


class Command(BaseCommand):
    help = 'Scraps quotes and loads into db.'

    def handle(self, *args, **options):
        quotes = self.get_quotes()

        for quote in quotes:
            a, created = Authors.objects.get_or_create(
                author=quote['author']
            )

            q = Quotes.objects.create(quote=quote['quote'], author=a)

            for tag in quote['tags']:
                t, created = Tags.objects.get_or_create(
                    tag=tag
                )
                q.tag.add(t)

    @staticmethod
    def get_quotes():
        all_data = []
        for i in range(1, 11):
            url = 'https://quotes.toscrape.com/page/'
            url = url + str(i)
            response = requests.get(url, headers={
                'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) '
                              'Chrome/99.0.4844.74 Safari/537.36'})
            response_html = response.text
            soup = BeautifulSoup(response_html, 'html.parser')
            for q in soup.find('div', {'class': 'container'}).find_all('div', class_='quote'):
                quote = q.find('span', class_='text')
                quote = quote.text
                author = q.find('small', class_='author')
                author = author.text
                quote_obj = {"quote": quote, "author": author}

                tags = []
                for t in q.find_all('a', class_='tag'):
                    tag = t.text
                    tags.append(tag)

                quote_obj['tags'] = tags

                all_data.append(quote_obj)

        return all_data