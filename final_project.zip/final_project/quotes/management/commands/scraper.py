from bs4 import BeautifulSoup
import requests

from django.core.management.base import BaseCommand
from quotes.models import Tags, Authors, Quotes


class Command(BaseCommand):
    help = 'Scraps quotes and loads into db.'

    def handle(self, *args, **options):
        quotes = self.get_quotes()

        for quote in quotes:
            a = Authors.objects.get_or_create(
                author=quote[1]
            )

            # a.save()
            for i in quote[2:]:
                t, created = Tags.objects.get_or_create(
                    tag=i
                )
                # t.save()
                # q = Quotes.objects.get_or_create(
                #     quote=quote[1],
                #     author=a[0],
                #     tag = t
                # )
            tag_list = []
            for i in quote[2:]:
                t, created = Tags.objects.get_or_create(
                    tag=i
                )
                tag_list.append(i)
                # t.save()
                # q = Quotes.objects.get_or_create(
                #     quote=quote[1],
                #     author=a[0],
                #     tag = t
            try:
                q = Quotes.objects.get(quote=quote[1], author=a[0])
                q = q.tag.set(tag_list)
            except Quotes.DoesNotExist:
                q = Quotes(
                    quote=quote[1],
                    author=a[0],
                    tag=t
                )
                q.save()
            # )

    @staticmethod
    def get_quotes():
        all_data = []
        for i in range(1, 11):
            url = 'https://quotes.toscrape.com/page/'
            url = url + str(i)
            response = requests.get(url, headers={
                'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) '
                              'Chrome/99.0.4844.74 Safari/537.36'})
            response_html = response.text
            soup = BeautifulSoup(response_html, 'html.parser')
            for q in soup.find('div', {'class': 'container'}).find_all('div', class_='quote'):
                quote = q.find('span', class_='text')
                quote = quote.text
                author = q.find('small', class_='author')
                author = author.text
                list1 = [quote, author]

                for t in q.find_all('a', class_='tag'):
                    tag = t.text
                    list1.append(tag)

                all_data.append(list1)

        return all_data
