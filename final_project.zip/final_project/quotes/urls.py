from django.urls import path
from django.contrib.auth.decorators import login_required
from .views import QuotesListView, QuotesCreateView

app_name = 'cars'
urlpatterns = [
    path('', QuotesListView.as_view(), name='quotes_list'),
    path('create/', QuotesCreateView.as_view(), name='quotes_create'),
]
