from django.db import models


# Create your models here.

class Tags(models.Model):
    tag = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.tag


class Authors(models.Model):
    author = models.CharField(max_length=60, null=False, unique=True)

    def __str__(self):
        return self.author


class Quotes(models.Model):
    quote = models.TextField(unique=True, null=False)
    author = models.ForeignKey(Authors, on_delete=models.CASCADE)
    tag = models.ManyToManyField(Tags)

    def __str__(self):
        return self.quote
