from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView

from .models import Tags, Authors, Quotes


class QuotesListView(ListView):
    model = Quotes
    paginate_by = 10
    template_name = 'quotes_list.html'


class QuotesMixin:
    model = Quotes
    fields = '__all__'
    success_url = reverse_lazy('quotes:quotes_list')


class QuotesCreateView(QuotesMixin, CreateView):
    fields = ('quote', 'tag')
    template_name = 'quotes_form.html'

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)
